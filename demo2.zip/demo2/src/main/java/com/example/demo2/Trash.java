package com.example.demo2;

public class Trash {

}

//if(counter%60 == 0)
//System.out.println(meteorsList.size());

                    /*for (int i=0; i < 100; i++) {
                        if (Integer.toString(number[i]).equals("1")) {
                            gamePane.getChildren().remove(meteorList.get(i).getObject());
                            meteorList.remove(i);
                            number[i] = 0;
                        }
                    }

                     */